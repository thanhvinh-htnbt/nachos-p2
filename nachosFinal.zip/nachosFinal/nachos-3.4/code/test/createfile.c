#include "syscall.h" 
#include "copyright.h" 
#define maxlen 32 
int 
main() 
{ 
	int len; 
 	char filename[maxlen +1]; 
	PrintString("\nNhap ten file can tao: ");
	ReadString(filename, maxlen + 1);
	/*Create a file*/ 
 	if (Create(filename) == -1) 
 	{ 
 		// xuất thông báo lỗi tạo tập tin 
		PrintString("\nTao tap tin khong thanh cong");
 	} 
 	else 
 	{ 
 		// xuất thông báo tạo tập tin thành công 
		PrintString("\nTao tap tin thanh cong");
 	} 
 	Halt(); 
}
